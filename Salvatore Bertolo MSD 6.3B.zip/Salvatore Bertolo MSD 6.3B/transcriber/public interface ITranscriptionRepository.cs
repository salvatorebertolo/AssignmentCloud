﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
namespace Transcriber
{
    public class InMemoryTranscriptionRepository : ITranscriptionRepository
    {
        private readonly Dictionary<string, string> _transcriptions = new();

        public string GetTranscriptionData(string postId)
        {
            if (_transcriptions.TryGetValue(postId, out var transcriptionData))
            {
                return transcriptionData;
            }

            return null;
        }

        public void SaveTranscriptionData(string postId, string transcriptionData)
        {
            _transcriptions[postId] = transcriptionData;
        }
    }
}