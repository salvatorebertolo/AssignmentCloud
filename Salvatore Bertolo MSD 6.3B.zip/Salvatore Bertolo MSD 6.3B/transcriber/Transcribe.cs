﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Google.Cloud.Speech.V1;
using System.IO;
using Microsoft.Extensions.Logging;
using Transcriber;

public class Transcribe
{
    private readonly ITranscriptionRepository _repo;
    private readonly ILogger<Transcribe> _logger;

    public Transcribe(ITranscriptionRepository repo, ILogger<Transcribe> logger)
    {
        _repo = repo;
        _logger = logger;
    }

    public async Task TranscribeFlacFile(string postId, string storageUri)
    {
        _logger.LogInformation("Starting transcription process for post ID: {PostId}", postId);

        var speechClient = SpeechClient.Create();

        var longOperation = speechClient.LongRunningRecognize(new RecognitionConfig()
        {
            Encoding = RecognitionConfig.Types.AudioEncoding.Flac,
            SampleRateHertz = 16000, // Adjust this based on the actual sample rate of the .flac file
            LanguageCode = "en-US",
            EnableAutomaticPunctuation = true,
            EnableWordTimeOffsets = true
        }, RecognitionAudio.FromStorageUri(storageUri));

        _logger.LogInformation("Transcription started. Waiting for completion...");

        longOperation = longOperation.PollUntilCompleted();

        var response = longOperation.Result;
        var transcriptBuilder = new StringBuilder();

        foreach (var result in response.Results)
        {
            foreach (var alternative in result.Alternatives)
            {
                transcriptBuilder.AppendLine(alternative.Transcript);
            }
        }

        // Save the transcription to the repository
        _repo.SaveTranscriptionData(postId, transcriptBuilder.ToString());

        _logger.LogInformation("Transcription completed and saved for post ID: {PostId}", postId);
    }

    public byte[] GetTranscriptionData(string postId)
    {
        var transcriptionData = _repo.GetTranscriptionData(postId);
        if (transcriptionData == null)
        {
            return null;
        }

        return Encoding.UTF8.GetBytes(transcriptionData);
    }
}