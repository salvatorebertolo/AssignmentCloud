﻿using Google.Cloud.Firestore;
using Google.Cloud.Firestore.Converters;
using System;

public class UtcDateTimeConverter : IFirestoreConverter<DateTime>
{
    public object ToFirestore(DateTime value)
    {
        return Timestamp.FromDateTime(value.ToUniversalTime());
    }

    public DateTime FromFirestore(object value)
    {
        if (value is Timestamp timestamp)
        {
            return timestamp.ToDateTime().ToUniversalTime();
        }
        else if (value is string dateString)
        {
            if (DateTime.TryParse(dateString, out DateTime parsedDate))
            {
                return parsedDate.ToUniversalTime();
            }
            else
            {
                throw new ArgumentException($"Unable to parse date string: {dateString}", nameof(value));
            }
        }
        else
        {
            throw new ArgumentException($"Unexpected data type: {value.GetType()}", nameof(value));
        }
    }
}