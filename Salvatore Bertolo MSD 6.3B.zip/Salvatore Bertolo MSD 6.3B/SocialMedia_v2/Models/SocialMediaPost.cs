﻿using Google.Cloud.Firestore;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace SocialMedia_V2.Models
{
    [FirestoreData]
    public class SocialMediaPost
    {
        [FirestoreProperty]
        public string UserId { get; set; }

        [FirestoreProperty]
        public string PostId { get; set; }

        [FirestoreProperty]
        public string Title { get; set; }

        [FirestoreProperty]
        public string Content { get; set; }

        [FirestoreProperty]
        public string Author { get; set; }

        [FirestoreProperty(ConverterType = typeof(UtcDateTimeConverter))]
        public DateTime Date { get; set; } = DateTime.UtcNow;

        [FirestoreProperty]
        public string ImageUrl { get; set; }

        [FirestoreProperty]
        public string ImageFilename { get; set; }

        [FirestoreProperty("VideoUrl")]
        public string VideoUrl { get; set; }

        public IFormFile Media { get; set; }

        [FirestoreProperty]
        public string VideoFilename { get; set; }

        public string Username { get; set; }

        [FirestoreProperty]
        public string BucketUri { get; set; }

        [FirestoreProperty]
        public string ThumbnailUrl { get; set; }

        [FirestoreProperty]
        public string ThumbnailFilename { get; set; }

        [FirestoreProperty]
        public string Status { get; set; }

        public List<DateTime> DownloadTimestamps { get; set; } = new List<DateTime>();
    }
}
