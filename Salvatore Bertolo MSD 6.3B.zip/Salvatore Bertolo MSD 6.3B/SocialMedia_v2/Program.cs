using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.Google;
using SocialMedia_V2.DataAccess;
using Google.Cloud.SecretManager.V1;
using SocialMedia_V2.Services;
using static SocialMedia_V2.Controllers.PostsController;
using Microsoft.Extensions.DependencyInjection;
using Transcriber; // Add this line

var builder = WebApplication.CreateBuilder(args);

// For laptop
System.Environment.SetEnvironmentVariable("GOOGLE_APPLICATION_CREDENTIALS", builder.Configuration["Authentication:Google:Credentials"]);

using var loggerFactory = LoggerFactory.Create(builder => builder.AddSimpleConsole());

// Add services to the container.
builder.Services.AddControllersWithViews();

// Create the client.
SecretManagerServiceClient client = SecretManagerServiceClient.Create();

// Access the secret version.
AccessSecretVersionResponse result = client.AccessSecretVersion("projects/cloudassign-385920/secrets/CloudAssign/versions/2");

string secretKey = result.Payload.Data.ToStringUtf8();

builder.Services.AddAuthentication(options =>
{
    options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = GoogleDefaults.AuthenticationScheme;
})
    .AddCookie()
    .AddGoogle(GoogleDefaults.AuthenticationScheme, options =>
    {
        options.ClientId = builder.Configuration["Authentication:Google:ClientId"];
        options.ClientSecret = secretKey;
    });

// Register the FirebaseStorageService
builder.Services.AddScoped<IStorageService, FirebaseStorageService>();

// Register the FirestoreRepository and pass the IStorageService to its constructor
builder.Services.AddScoped<FirestoreRepository>(provider =>
    new FirestoreRepository(builder.Configuration, provider.GetService<IStorageService>(), loggerFactory.CreateLogger<FirestoreRepository>()));

// Register the ITranscriptionRepository and its implementation
builder.Services.AddSingleton<ITranscriptionRepository, InMemoryTranscriptionRepository>(); // Add this line

// Register the Transcribe class and pass the ITranscriptionRepository and ILogger to its constructor
builder.Services.AddScoped<Transcribe>(provider =>
    new Transcribe(provider.GetService<ITranscriptionRepository>(), provider.GetService<ILogger<Transcribe>>()));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();