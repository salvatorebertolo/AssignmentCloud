﻿using System;
using System.IO;
using System.Threading.Tasks;
using Firebase.Storage;
using Microsoft.AspNetCore.Http;
using SocialMedia_V2.Controllers;
using static SocialMedia_V2.Controllers.PostsController;


namespace SocialMedia_V2.Services
{
    public class FirebaseStorageService : IStorageService
    {
        private readonly string _firebaseStorageBucket = "cloud-bucket-56d8a.appspot.com";
        private readonly ILogger<FirebaseStorageService> _logger;

        public FirebaseStorageService(IConfiguration config, ILogger<FirebaseStorageService> logger)
        {
            //_storage = new FirebaseStorage(config.GetValue<string>("FirebaseStorageBucket"));
            _logger = logger;
        }

        public async Task<string> UploadFileAsync(IFormFile file)
        {
            var stream = new MemoryStream();
            await file.CopyToAsync(stream);
            stream.Position = 0;

            // Initialize Firebase Storage with your bucket URL
            var storage = new FirebaseStorage(_firebaseStorageBucket);

            // Create a unique filename using a GUID
            var uniqueFilename = $"{Guid.NewGuid().ToString()}{Path.GetExtension(file.FileName)}";

            // Upload the file to Firebase Storage
            var storageRef = storage.Child("uploads").Child(uniqueFilename);
            await storageRef.PutAsync(stream);

            // Get the download URL of the uploaded file
            var url = await storageRef.GetDownloadUrlAsync();

            _logger.LogInformation($"UploadFileAsync: File uploaded, URL: {url}");
            // Return the URL of the uploaded file
            return url;
        }

        public async Task DeleteFileAsync(string fileName)
        {
            // Initialize Firebase Storage with your bucket URL
            var storage = new FirebaseStorage(_firebaseStorageBucket);

            // Get the reference to the file to be deleted
            var fileRef = storage.Child("uploads").Child(fileName);

            // Delete the file
            await fileRef.DeleteAsync();
        }
    }
}