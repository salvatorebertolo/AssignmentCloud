﻿using Google.Apis.Auth.OAuth2;
using Google.Cloud.Firestore;
using SocialMedia_V2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using static SocialMedia_V2.Controllers.PostsController;

namespace SocialMedia_V2.DataAccess
{
    public class FirestoreRepository 
    {
        private FirestoreDb _db;
        private readonly String _projectId;
        private readonly IStorageService _storageService;
        private readonly ILogger _logger;

        public FirestoreRepository(IConfiguration config, IStorageService storageService, ILogger logger)
        {
            _projectId = config.GetValue<string>("Authentication:Google:ProjectId");
            _db = FirestoreDb.Create(_projectId);
            _storageService = storageService;
            _logger = logger;
        }

        public async void AddPost(SocialMediaPost p)
        {
            await _db.Collection("posts").AddAsync(p);
        }

        public async Task<List<SocialMediaPost>> GetPosts(string userId)
        {
            _logger.LogInformation("Fetching posts from the Firestore collection");
            List<SocialMediaPost> posts = new List<SocialMediaPost>();
            Query userPostsQuery = _db.Collection("posts").WhereEqualTo("UserId", userId);
            QuerySnapshot userPostsQuerySnapshot = await userPostsQuery.GetSnapshotAsync();
            foreach (DocumentSnapshot s in userPostsQuerySnapshot.Documents)
            {
                SocialMediaPost p = s.ConvertTo<SocialMediaPost>();
                _logger.LogInformation($"Fetched post with ID: {p.PostId}, VideoUrl: {p.VideoUrl}");
                posts.Add(p);
            }

            return posts;
        }

        public async Task<SocialMediaPost> GetPostById(string id)
        {
            Query postQuery = _db.Collection("posts").WhereEqualTo("PostId", id);
            QuerySnapshot postQuerySnapshot = await postQuery.GetSnapshotAsync();

            DocumentSnapshot documentSnapshot = postQuerySnapshot.Documents.FirstOrDefault();
            if (documentSnapshot == null)
            {
                return null;
            }
            else
            {
                SocialMediaPost post = documentSnapshot.ConvertTo<SocialMediaPost>();
                return post;
            }
        }

        public async Task UpdatePost(SocialMediaPost p)
        {
            Query postQuery =  _db.Collection("posts").WhereEqualTo("PostId", p.PostId);
            QuerySnapshot postQuerySnapshot = await postQuery.GetSnapshotAsync();

            DocumentSnapshot documentSnapshot = postQuerySnapshot.Documents.FirstOrDefault();

            if (documentSnapshot != null)
            {
                string id = documentSnapshot.Id;
                DocumentReference postRef = _db.Collection("posts").Document(id);
                await postRef.SetAsync(p);
            }
            else
            {
                throw new Exception("No post with Id " + p.PostId);
            }
        }

        public async Task UpdatePost(string id, string content)
        {
            Query postQuery = _db.Collection("posts").WhereEqualTo("PostId",id);
            QuerySnapshot postQuerySnapshot = await postQuery.GetSnapshotAsync();

            DocumentSnapshot documentSnapshot = postQuerySnapshot.Documents.FirstOrDefault(); //Getting first item from the list of Snapshots
            SocialMediaPost post = documentSnapshot.ConvertTo<SocialMediaPost>(); //Casting from Document Snapshot to Social Media Post
            DocumentReference postRef = _db.Collection("posts").Document(documentSnapshot.Id); //Getting document reference (where it is located in db)

            post.Content = content; //changing the content of the post
            await postRef.SetAsync(post); //overwriting the post
        }

        public async Task CreatePost(SocialMediaPost post)
        {
            CollectionReference postsCollection = _db.Collection("posts");

            _logger.LogInformation($"Saving post with ID: {post.PostId}, VideoUrl: {post.VideoUrl}");
            await postsCollection.AddAsync(post);
        }

        public async Task<bool> DeletePost(string id)
        {
            _logger.LogInformation($"Attempting to delete post with Id {id}");

            // Get Root Info
            Query postQuery = _db.Collection("posts").WhereEqualTo("PostId", id);
            QuerySnapshot postQuerySnapshot = await postQuery.GetSnapshotAsync();

            DocumentSnapshot documentSnapshot = postQuerySnapshot.Documents.FirstOrDefault();

            if (documentSnapshot != null)
            {
                string newId = documentSnapshot.Id;

                DocumentReference postRef = _db.Collection("posts").Document(newId);

                SocialMediaPost p = postQuerySnapshot.Documents[0].ConvertTo<SocialMediaPost>();

                // Delete Image from Storage
                if (p.ImageFilename != null)
                {
                    _logger.LogInformation($"Deleting image {p.ImageFilename}");
                    await _storageService.DeleteFileAsync(p.ImageFilename);
                }

                // Delete Post
                _logger.LogInformation($"Deleting post from Firestore with document Id {newId}");
                await postRef.DeleteAsync();
                return true;
            }
            else
            {
                // Log a warning message
                _logger.LogWarning($"No post found with Id {id}");
                return false;
            }
        }
    }
}

