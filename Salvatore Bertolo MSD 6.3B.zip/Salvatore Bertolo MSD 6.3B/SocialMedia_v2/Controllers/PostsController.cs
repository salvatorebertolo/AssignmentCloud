﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SocialMedia_V2.DataAccess;
using SocialMedia_V2.Models;
using System.Reflection;
using Microsoft.Extensions.Logging;
using System.Security.Claims;
using Google.Api;
using Microsoft.AspNetCore.Hosting;
using Google;
using Microsoft.Extensions.Hosting.Internal;

namespace SocialMedia_V2.Controllers
{
    public class PostsController : Controller
    {
        private FirestoreRepository _repo;
        private readonly ILogger<PostsController> _logger;
        private readonly IStorageService _storage;
        private readonly IWebHostEnvironment _hostingEnvironment;

        public PostsController(FirestoreRepository repo, ILogger<PostsController> logger, IStorageService storage, IWebHostEnvironment hostingEnvironment)
        {
            _repo = repo;
            _logger = logger;
            _storage = storage;
            _hostingEnvironment = hostingEnvironment;
        }

        [Authorize]
        public async Task<IActionResult> Index()
        {
            var loggedInUserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var allPosts = await _repo.GetPosts(loggedInUserId);

            // Filter the posts to show only the ones related to the currently logged-in user
            var userPosts = allPosts.Where(post => post.UserId == loggedInUserId).ToList();

            foreach (var post in userPosts)
            {
                if (!string.IsNullOrEmpty(post.VideoUrl))
                {
                    _logger.LogInformation($"Post ID: {post.PostId}, VideoUrl: {post.VideoUrl}");
                }
            }

            ViewData["Posts"] = userPosts;

            return View(userPosts);
        }

        [Authorize]
        public IActionResult Create()
        {
            return View();
        }

        [Authorize]
        public IActionResult Update()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(SocialMediaPost post, IFormFile media, IFormFile thumbnail)
        {
            _logger.LogInformation($"Create action called with post: {post?.Title}, media: {media?.FileName}");

            // Process the media file
            if (media != null)
            {
                post.PostId = Guid.NewGuid().ToString();

                // Save the file to the appropriate folder
                var fileName = Path.GetFileName(media.FileName);
                var fileExtension = Path.GetExtension(fileName).ToLower();

                _logger.LogInformation($"File name: {fileName}, file extension: {fileExtension}");

                var imagePath = Path.Combine(_hostingEnvironment.WebRootPath, "images");
                var videoPath = Path.Combine(_hostingEnvironment.WebRootPath, "videos");

                var isImage = fileExtension == ".jpg" || fileExtension == ".jpeg" || fileExtension == ".png" || fileExtension == ".gif";
                var isVideo = fileExtension == ".mp4" || fileExtension == ".webm" || fileExtension == ".ogg";

                _logger.LogInformation($"Is image: {isImage}, is video: {isVideo}");

                string videoUrl = null;

                if (isImage)
                {
                    var imageSavePath = Path.Combine(imagePath, fileName);
                    using (var fileStream = new FileStream(imageSavePath, FileMode.Create))
                    {
                        await media.CopyToAsync(fileStream);
                    }

                    post.ImageUrl = "/images/" + fileName;
                }
                else if (isVideo)
                {
                    videoUrl = await _storage.UploadFileAsync(media);
                    post.VideoFilename = fileName; // Set the VideoFilename field
                    _logger.LogInformation($"Video uploaded, VideoUrl: {videoUrl}");
                }

                // Upload the thumbnail image
                if (thumbnail != null)
                {
                    if (!Directory.Exists(imagePath))
                    {
                        Directory.CreateDirectory(imagePath);
                    }
                    _logger.LogInformation($"Processing thumbnail: {thumbnail.FileName}");

                    var thumbnailFileName = Path.GetFileName(thumbnail.FileName);
                    var thumbnailSavePath = Path.Combine(imagePath, thumbnailFileName);
                    using (var fileStream = new FileStream(thumbnailSavePath, FileMode.Create))
                    {
                        await thumbnail.CopyToAsync(fileStream);
                    }

                    post.ThumbnailUrl = "/images/" + thumbnailFileName;
                    _logger.LogInformation($"Thumbnail uploaded, ThumbnailUrl: {post.ThumbnailUrl}");
                }
                else
                {
                    _logger.LogWarning("Thumbnail is null or not provided.");
                    ModelState.AddModelError("Thumbnail", "Thumbnail image is required.");
                    return View(post);
                }

                // Set the Author and Date
                post.Author = User.Identity.Name;
                post.UserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                post.Date = DateTime.UtcNow;

                // Set the VideoUrl field
                post.VideoUrl = videoUrl;

                // Create the post
                await _repo.CreatePost(post);
                _logger.LogInformation($"Post ID: {post.PostId}, VideoUrl: {post.VideoUrl}");

                return RedirectToAction(nameof(Index));
            }
            else
            {
                ModelState.AddModelError("Media", "Media file is required.");
            }

            return View(post);
        }

        [HttpGet] //will be called when the user first clicks on the Edit link
        public async Task<IActionResult> GetPostById(string id)
        {
            var p = await _repo.GetPostById(id);
            return View("Update", p);
        }

        [HttpPost]
        public async Task<IActionResult> Update(SocialMediaPost p)
        {
            try
            {
                Guid uuid = Guid.NewGuid();

                p.Author = @User.Identity.Name;
                p.Date = DateTime.UtcNow;

                await _repo.UpdatePost(p);
                TempData["success"] = "updated successfully";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["error"] = "error occurred. check your inputs, try again later";
            }

            return View(p);

        }

        [HttpPut]
        public async Task<IActionResult> UpdatePost (IFormCollection formCollection)
        {
            try
            {
                await _repo.UpdatePost(formCollection["id"], formCollection["content"]);
            }
            catch(Exception ex)
            {

            }

            return View();
        }


        public IActionResult DeletePost(string id)
        {
            _repo.DeletePost(id);
            return RedirectToAction("Index");
        }

        public interface IStorageService
        {
            Task<string> UploadFileAsync(IFormFile file);
            Task DeleteFileAsync(string fileName);
        }

        [HttpDelete]
        public async Task<IActionResult> DeletePost(IFormCollection formCollection)
        {
            try
            {
                bool isDeleted = await _repo.DeletePost(formCollection["id"]);

                if (!isDeleted)
                {
                    // Handle the case when the post is not found, e.g., return a BadRequest response
                    return BadRequest("Post not found.");
                }
            }
            catch (Exception ex)
            {
                // Log the exception details
                _logger.LogError(ex, "An error occurred while deleting the post.");
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> DownloadFile(string postId)
        {
            var post = await _repo.GetPostById(postId);

            if (post == null)
            {
                return NotFound();
            }

            // Update the download timestamps
            post.DownloadTimestamps.Add(DateTime.UtcNow);
            await _repo.UpdatePost(post);

            // Log the download request
            _logger.LogInformation($"Video with postId {postId} is being downloaded by user {User.Identity.Name} at {DateTime.UtcNow}");

            // Download the file content
            string fileUrl = post.VideoUrl ?? post.ImageUrl;
            if (string.IsNullOrEmpty(fileUrl))
            {
                return BadRequest("No file to download.");
            }

            using var httpClient = new HttpClient();
            byte[] fileContent;
            try
            {
                fileContent = await httpClient.GetByteArrayAsync(fileUrl);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error downloading file from {FileUrl}", fileUrl);
                return StatusCode(StatusCodes.Status500InternalServerError, "Error downloading file.");
            }

            // Get file extension and content type
            string fileExtension = Path.GetExtension(fileUrl);
            string contentType = GetContentTypeByFileExtension(fileExtension);

            // Return the file content as a File result
            string fileName = post.VideoFilename ?? post.ImageFilename;
            return File(fileContent, contentType, fileName);
        }

        private string GetContentTypeByFileExtension(string fileExtension)
        {
            // Add more content types for other file extensions if needed
            return fileExtension.ToLower() switch
            {
                ".jpg" => "image/jpeg",
                ".jpeg" => "image/jpeg",
                ".png" => "image/png",
                ".mp4" => "video/mp4",
                _ => "application/octet-stream",
            };
        }

    }
}
