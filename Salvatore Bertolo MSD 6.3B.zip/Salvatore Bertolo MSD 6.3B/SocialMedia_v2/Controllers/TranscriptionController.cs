﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Transcriber; 

[ApiController]
[Route("api/transcribe")]
public class TranscriptionController : ControllerBase
{
    private readonly ITranscriptionRepository _repo;
    private readonly ILogger<Transcribe> _logger;

    public TranscriptionController(ITranscriptionRepository repo, ILogger<Transcribe> logger)
    {
        _repo = repo;
        _logger = logger;
    }

    [HttpPost]
    public async Task<IActionResult> Transcribe(string videoUrl)
    {
        if (string.IsNullOrEmpty(videoUrl))
        {
            return BadRequest("Video URL is required.");
        }

        // Create an instance of the Transcribe class
        var transcriber = new Transcribe(_repo, _logger);

        // Call the TranscribeFlacFile method to start the transcription process.
        await transcriber.TranscribeFlacFile("cloudassign-385920", videoUrl);

        _logger.LogInformation($"Transcription started for VideoUrl: {videoUrl}");

        return Ok("Transcription started.");
    }
}