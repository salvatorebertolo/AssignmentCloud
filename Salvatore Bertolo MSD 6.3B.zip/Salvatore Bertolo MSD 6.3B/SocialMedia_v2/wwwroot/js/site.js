﻿//const DeletePost = (id) => {
//    var formData = new FormData();
//    formData.append("id", id);
//    $.ajax({
//        type: "DELETE",
//        //url: '@Url.Action("DeletePost", "Posts")',
//        url: '/Posts/DeletePost',
//        contentType: false,
//        processData: false,
//        cache: false,
//        data: formData,
//        success: () => InformUserDelete("Delete Successful"),
//        error: () => InformUser("Delete Failed")
//    });
//};

//const UpdatePost = (id) => {
//    var formData = new FormData();
//    formData.append("id", id);
//    formData.append("name", "123");
//    formData.append("email", "123");
//    $.ajax({
//        type: 'POST',
//        url: '/Posts/Update',
//        contentType: false,
//        processData: false,
//        cache: false,
//        data: formData,
//        success: () => InformUser("Update Successful"),
//        error: () => InformUser("Update Failed")
//    });
//};

//const InformUser = (message) => {
//    console.log(message);
//};

//const InformUserDelete = (message) => {
//    console.log(message);
//    window.location.reload();
//}

//function detailsClick(id) {
//    var formData = new FormData();
//    formData.append("id", id);

//    var detailsButton = $("#detailsButton_"+formData.get("id"));

//    detailsButton.toggleClass('show');
//    if (detailsButton.hasClass('show')) {
//        detailsButton.text('Hide Details');
//    } else {
//        detailsButton.text('Show Details');
//    }
//}

//function goToUpdate(id) {
//    window.location.href = '/Posts/Update/' + id;
//}
